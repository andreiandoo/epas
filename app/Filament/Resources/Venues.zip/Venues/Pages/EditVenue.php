<?php
namespace App\Filament\Resources\Venues\VenueResource\Pages;

use App\Filament\Resources\Venues\VenueResource;
use Filament\Resources\Pages\EditRecord;

class EditVenue extends EditRecord
{
    protected static string $resource = VenueResource::class;
}
