<?php

namespace App\Filament\Resources\Venues\VenueResource\Pages;

use App\Filament\Resources\Venues\VenueResource;
use Filament\Resources\Pages\ViewRecord;
use Filament\Actions\Action;
use App\Filament\Resources\Venues\Widgets\VenueHeaderWidget;
use App\Filament\Resources\Venues\Widgets\VenueStatsOverview;
use App\Filament\Resources\Venues\Widgets\VenueEventsTable;

class ViewVenue extends ViewRecord
{
    protected static string $resource = VenueResource::class;

    protected function hasInfolist(): bool
    {
        // vrem doar widget-urile custom, nu infolist cu câmpuri read-only
        return false;
    }

    public function getHeaderWidgetsColumns(): array|int
    {
        // un singur “stack” vertical: hero -> stats -> tabel
        return 1;
    }

    protected function getHeaderActions(): array
    {
        // Actions eliminated - use table columns for navigation
        return [];
    }

    protected function getHeaderWidgets(): array
    {
        return [
            VenueHeaderWidget::class,
            VenueStatsOverview::class,
            VenueEventsTable::class,
        ];
    }
}
